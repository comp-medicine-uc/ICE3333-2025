import numpy as np
import matplotlib.pylab as plt
import os

x = np.linspace(0.,10.,1001)
y = np.sin(x)

plt.figure()
plt.plot(x,y,'-')
plt.xlabel('x')
plt.ylabel('y')

# Save figure

path = os.path.abspath('')
path = os.path.abspath(os.path.join(path, os.pardir))+'/figures/'

plt.savefig(path+'sin.pdf')
